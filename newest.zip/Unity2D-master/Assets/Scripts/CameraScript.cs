﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		//GameObject cam = GameObject.Find("MainCamera");
		//Debug.Log(cam.transform.rotation);
		//cam.transform.position(0,0,0);

		
	}
}
